chrome.runtime.onInstalled.addListener(() => {
    console.log("Google Meet Supporter installed.");
  });
  